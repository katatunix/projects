Imports FastColoredTextBoxNS
Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Text.RegularExpressions
Imports System.Windows.Forms

Namespace TesterVB
    Public Class CustomStyleSample
        Inherits Form

        Private ellipseStyle As EllipseStyle = New EllipseStyle()

        Private components As IContainer = Nothing

        Private label1 As Label

        Private fctb As FastColoredTextBox

        Public Sub New()
            Me.InitializeComponent()
            Me.fctb.Text = "Available historical resources suggest that Babylon was at first a small town which had sprung up by the beginning of the 3rd millennium BC. The town flourished and attained prominence and political repute with the rise of the First Babylonian Dynasty. Claiming to be the successor of the ancient Eridu, Babylon eclipsed Nippur as the ""holy city"" of Mesopotamia around the time Hammurabi first unified the Babylonian Empire, and again became the seat of the Neo-Babylonian Empire from 612 to 539 BC. The Hanging Gardens of Babylon were one of the Seven Wonders of the Ancient World."
        End Sub

        Private Sub fctb_TextChanged(sender As Object, e As TextChangedEventArgs)
            e.ChangedRange.ClearStyle(New Style() {Me.ellipseStyle})
            e.ChangedRange.SetStyle(Me.ellipseStyle, "\bBabylon\b", RegexOptions.IgnoreCase)
        End Sub

        Protected Overrides Sub Dispose(disposing As Boolean)
            If disposing AndAlso Me.components IsNot Nothing Then
                Me.components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

        Private Sub InitializeComponent()
            Me.label1 = New Label()
            Me.fctb = New FastColoredTextBox()
            MyBase.SuspendLayout()
            Me.label1.Dock = DockStyle.Top
            Me.label1.Font = New Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204)
            Me.label1.Location = New Point(0, 0)
            Me.label1.Name = "label1"
            Me.label1.Size = New Size(600, 39)
            Me.label1.TabIndex = 1
            Me.label1.Text = "This example shows how to create own custom style."
            Me.fctb.AutoIndent = False
            Me.fctb.AutoScrollMinSize = New Size(565, 15)
            Me.fctb.BackBrush = Nothing
            Me.fctb.BorderStyle = BorderStyle.FixedSingle
            Me.fctb.Cursor = Cursors.IBeam
            Me.fctb.DisabledColor = Color.FromArgb(100, 180, 180, 180)
            Me.fctb.Dock = DockStyle.Fill
            Me.fctb.Font = New Font("Consolas", 9.75F)
            Me.fctb.LeftBracket = "("
            Me.fctb.LeftPadding = 3
            Me.fctb.Location = New Point(0, 39)
            Me.fctb.Name = "fctb"
            Me.fctb.Paddings = New Padding(5)
            Me.fctb.PreferredLineWidth = 80
            Me.fctb.RightBracket = ")"
            Me.fctb.SelectionColor = Color.FromArgb(50, 0, 0, 255)
            Me.fctb.ShowLineNumbers = False
            Me.fctb.Size = New Size(600, 266)
            Me.fctb.TabIndex = 2
            Me.fctb.WordWrap = True
            Me.fctb.WordWrapMode = WordWrapMode.WordWrapPreferredWidth
            AddHandler Me.fctb.TextChanged, New EventHandler(Of TextChangedEventArgs)(AddressOf Me.fctb_TextChanged)
            MyBase.AutoScaleDimensions = New SizeF(6.0F, 13.0F)
            MyBase.AutoScaleMode = AutoScaleMode.Font
            MyBase.ClientSize = New Size(600, 305)
            MyBase.Controls.Add(Me.fctb)
            MyBase.Controls.Add(Me.label1)
            MyBase.Name = "CustomStyleSample"
            Me.Text = "Custom style sample"
            MyBase.ResumeLayout(False)
        End Sub
    End Class
End Namespace
