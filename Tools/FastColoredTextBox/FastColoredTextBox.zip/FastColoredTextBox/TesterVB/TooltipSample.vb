Imports FastColoredTextBoxNS
Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Windows.Forms

Namespace TesterVB
    Public Class TooltipSample
        Inherits Form

        Private lastMouseCoord As Point = Point.Empty

        Private components As IContainer = Nothing

        Private label1 As Label

        Private fctb As FastColoredTextBox

        Private tm As Timer

        Private tt As ToolTip

        Public Sub New()
            Me.InitializeComponent()
        End Sub

        Private Sub CancelToolTip()
            Me.tm.[Stop]()
            Me.tt.Hide(Me)
        End Sub

        Private Sub tb_MouseMove(sender As Object, e As MouseEventArgs)
            If Me.lastMouseCoord <> e.Location Then
                Me.CancelToolTip()
                Me.tm.Start()
            End If
            Me.lastMouseCoord = e.Location
        End Sub

        Private Sub tb_MouseLeave(sender As Object, e As EventArgs)
            Me.CancelToolTip()
        End Sub

        Private Sub tb_TextChanged(sender As Object, e As TextChangedEventArgs)
            Me.CancelToolTip()
        End Sub

        Private Sub tm_Tick(sender As Object, e As EventArgs)
            Me.tm.[Stop]()
            Dim place As Place = Me.fctb.PointToPlace(Me.lastMouseCoord)
            Dim p As Point = Me.fctb.PlaceToPoint(place)
            If Math.Abs(p.X - Me.lastMouseCoord.X) <= Me.fctb.CharWidth * 2 AndAlso Math.Abs(p.Y - Me.lastMouseCoord.Y) <= Me.fctb.CharHeight * 2 Then
                Dim r As Range = New Range(Me.fctb, place, place)
                Dim hoverWord As String = r.GetFragment("[a-zA-Z]").Text
                If Not hoverWord = "" Then
                    Dim text As String = "Help for " + hoverWord
                    Me.tt.ToolTipTitle = hoverWord
                    Me.tt.SetToolTip(Me.fctb, text)
                    Me.tt.Show(text, Me.fctb, New Point(Me.lastMouseCoord.X, Me.lastMouseCoord.Y + Me.fctb.CharHeight))
                End If
            End If
        End Sub

        Protected Overrides Sub Dispose(disposing As Boolean)
            If disposing AndAlso Me.components IsNot Nothing Then
                Me.components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

        Private Sub InitializeComponent()
            Me.components = New Container()
            Dim resources As ComponentResourceManager = New ComponentResourceManager(GetType(TooltipSample))
            Me.label1 = New Label()
            Me.fctb = New FastColoredTextBox()
            Me.tm = New Timer(Me.components)
            Me.tt = New ToolTip(Me.components)
            MyBase.SuspendLayout()
            Me.label1.Dock = DockStyle.Top
            Me.label1.Font = New Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204)
            Me.label1.Location = New Point(0, 0)
            Me.label1.Name = "label1"
            Me.label1.Size = New Size(355, 30)
            Me.label1.TabIndex = 4
            Me.label1.Text = "This example shows tooltips for words under mouse."
            Me.fctb.AutoScrollMinSize = New Size(32, 285)
            Me.fctb.BackBrush = Nothing
            Me.fctb.Cursor = Cursors.IBeam
            Me.fctb.DisabledColor = Color.FromArgb(100, 180, 180, 180)
            Me.fctb.Dock = DockStyle.Fill
            Me.fctb.Font = New Font("Consolas", 9.75F)
            Me.fctb.Language = Language.CSharp
            Me.fctb.LeftBracket = "("
            Me.fctb.Location = New Point(0, 30)
            Me.fctb.Name = "fctb"
            Me.fctb.Paddings = New Padding(0)
            Me.fctb.[ReadOnly] = True
            Me.fctb.RightBracket = ")"
            Me.fctb.SelectionColor = Color.FromArgb(50, 0, 0, 255)
            Me.fctb.Size = New Size(355, 282)
            Me.fctb.TabIndex = 5
            Me.fctb.Text = "    #region Char" & vbCrLf & vbCrLf & "   /// <summary>" & vbCrLf & "   /// Char and style" & vbCrLf & "   /// </summary>" & vbCrLf & "   struct Char" & vbCrLf & "   {" & vbCrLf & "       public char c;" & vbCrLf & "       public StyleIndex style;" & vbCrLf & vbCrLf & "       public Char(char c)" & vbCrLf & "       {" & vbCrLf & "           this.c = c;" & vbCrLf & "           style = StyleIndex.None;" & vbCrLf & "       }" & vbCrLf & "   }" & vbCrLf & "   #endregion"
            Me.fctb.WordWrap = True
            AddHandler Me.fctb.TextChanged, New EventHandler(Of TextChangedEventArgs)(AddressOf Me.tb_TextChanged)
            AddHandler Me.fctb.MouseLeave, New EventHandler(AddressOf Me.tb_MouseLeave)
            AddHandler Me.fctb.MouseMove, New MouseEventHandler(AddressOf Me.tb_MouseMove)
            Me.tm.Interval = 500
            AddHandler Me.tm.Tick, New EventHandler(AddressOf Me.tm_Tick)
            MyBase.AutoScaleDimensions = New SizeF(6.0F, 13.0F)
            MyBase.AutoScaleMode = AutoScaleMode.Font
            MyBase.ClientSize = New Size(355, 312)
            MyBase.Controls.Add(Me.fctb)
            MyBase.Controls.Add(Me.label1)
            MyBase.Name = "TooltipSample"
            Me.Text = "TooltipSample"
            MyBase.ResumeLayout(False)
        End Sub
    End Class
End Namespace
