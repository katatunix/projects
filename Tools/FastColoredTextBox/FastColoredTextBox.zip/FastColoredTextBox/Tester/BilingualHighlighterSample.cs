﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using FastColoredTextBoxNS;

namespace Tester
{
    public partial class BilingualHighlighterSample : Form
    {
        public BilingualHighlighterSample()
        {
            InitializeComponent();
        }

        private void BilingualHighlighterSample_Load(object sender, EventArgs e)
        {
            tb.Text =
    @"<html>
 <head></head>
 <body>
 <ul> 
  <?php for($i=1;$i<=5;$i++){ ?>
  <li>Menu Item <?php echo $i; ?></li> 
  <?php } ?>
 </ul> 
</body>
</html>";
        }

        private void tb_TextChangedDelayed(object sender, TextChangedEventArgs e)
        {
            var tb = (FastColoredTextBox) sender;
            
            //highlight html
            tb.SyntaxHighlighter.HTMLSyntaxHighlight(tb.Range);
            //find PHP fragments
            foreach(var r in tb.GetRanges(@"<\?php.*?\?>", RegexOptions.Singleline))
            {
                //remove HTML highlighting from this fragment
                r.ClearStyle(StyleIndex.All);
                //do PHP highlighting
                tb.SyntaxHighlighter.PHPSyntaxHighlight(r);
            }
        }
    }
}
